from django.http import HttpResponse


def main_off(request):
    return HttpResponse("coming soon")
